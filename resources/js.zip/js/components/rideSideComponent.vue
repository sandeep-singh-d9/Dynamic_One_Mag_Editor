<template>
	<div class="col-sm-10 right_side">
		<iconPreviewComponent/>
		 <button class="save_ifc_to_db" @click="saveFcValueToDb">Save Preview</button>
        <div class="preview_responsive">
	    	<div class="sub_right_side preview_content">
				<div class="row align-items-center">
					<div class="col-8 align-self-center someBlock"></div>
				</div>
	       		<frontCover/>
	       <!-- <IfcCover/>    -->
	    	</div>
	    </div>
	</div>
</template>

<script>
export default {
	data(){
		return{
			fcContent :''
		}
	},
   mounted(){
	   $(document).ready(function(){
		   		var obj = {},
    someBlock = $('.someBlock');

    function getValues() {
        obj.textVal = $('#textInput').val();
        obj.percentVal = $('#percentInput').val();
        obj.durationVal = $('#durationInput').val();
    }
    getValues();
        someBlock.preloader({
            text: obj.textVal,
            percent: obj.percentVal,
            duration: obj.durationVal
        });
  setTimeout(function(){
    someBlock.preloader('remove');
  }, 4000)
	   })

   		this.fcContent = $('.preview_content').html(); 
		this.ACTION_CHANGE_STATE(['fcPreview', this.fcContent])
	},
    methods:{  
      
    }, 
}
</script>

<style>

</style>
