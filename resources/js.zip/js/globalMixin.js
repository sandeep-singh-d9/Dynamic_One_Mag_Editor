import LeftSideComponent from './components/leftSideComponent'
import RightSideComponent from './components/rideSideComponent'
import { mapState, mapActions, mapGetters, mapMutations } from 'vuex';
import iconHoverComponent from './components/common/iconHoverComponent'
import iconHoverIfcComponent from './components/common/iconHoverIfcComponent'
// import iconHoverComponentIfc from './components/common/iconHoverComponent'
// import modelInputComponent from './components/model/modelInputComponent'
import UplaodArea from './components/model/imageUploadAreaComponent'
import IfcCover from './components/ifcComponent'
import frontCover from './components/frontCoverComponent'
import iconPreviewComponent from './components/common/iconPreviewComponent'
export const globalMixin = {
    components :{
        LeftSideComponent,
        RightSideComponent,
        iconHoverComponent,
        // iconHoverComponentIfc,
        // modelInputComponent, 
        UplaodArea,
        IfcCover,
        frontCover,
        iconHoverIfcComponent,
        iconPreviewComponent
    },
    computed: {
          

        ...mapState([
            'fcAddMediaShow',
            'showFrontCover',
            'showFrontInsideCover',
            'imagePath',
            'imageIfcPath',
            'imageIfcSignaturePath',
            'imageIbcProfilePath',
            'imageIbcMainPath',
            'imageIbcLogoPath',
            'imageBcLogoPath',
            'defaultImagePath',
            'defaultIfcImagePath',
            'defaultIfcSignaturePath',
            'defaultIbcProfilePath',
            'defaultIbcMainImagePath',
            'defaultIbcLogoImagePath',
            'fcLogoText',
            'ifcRightTextInputValue',
            'textAlign',
            'hideFcText',
            'displayTextArea',
            'displayIfcTextArea',
            'fcLogoTextDisplay',
            'openModal',
            'setIfc_bind',
            'setIfcLogo_bind',
            'setIfcSignature_bind',
            'setIbcProfile_bind',
            'setIbcMainImage_bind',
            'setIbcLogoImage_bind',
            'openIfcModalForLogo',
            'openIfcModalForSignature',
            'openIbcModal',
            'openIfcModalForText',
            'defaultIfcLogoPath',
            'imageIfcLogoPath',
            'ifcTextDisplay',
            'ifcRightTextDisplay',
            'ifcText',
            'ifcRightText',
            'displayTextAreaFor',
            'displayIbcProfileMedia',
            'displayIbcMainMedia',
            'displayIbcLogoMedia',
            'ifcTitleText',
            'ifcCompanyName',
            'designation1',
            'designation2',
            'designation3',
            'designationTitle1',
            'designationTitle2',
            'designationTitle3',
            'designationTitle4',
            'addressIfc1',
            'directPhoneIfc',
            'officePhone' ,
            'websiteUrlIfc',
            'emailIfc' ,
            'stNumberIfc',
            'showTextAreaIfcRight',
            'ifcRightTextValue',
            'showCover',
            'ibcTitleText',
            'ibcCompanyNameText',
            'ibcAddressText',
            'ibcAddressText1',
            'ibcPhoneNumberText',
            'ibcOfficeNumberText',
            'ibcWebsiteText',
            'ibcEmailText',
            'openHeaderContent',
            'openFooterContent',

            'bcTitleHeaderText',
            'bcAddressHeaderBcText',
            'bcAddressHeaderBc1Text',
            'bcCityHeaderText',
            'bcCountryHeaderText',

            'bcTitleText',
            'bcCompanyNameText',
            'bcAddressText',
            'bcAddressText1',
            'bcPhoneNumberText',
            'bcOfficeNumberText',
            'bcWebsiteText',
            'bcEmailText',
            'previewFc',
            'displayBcLogoMedia',
            'setBcLogoImage_bind',


            'fcCheckboxChoose',
            'fcModalHide',
            'defaultBcLogoImagePath',
            'fcTextInputValueEditor',

        ])
    },
    data(){
       return{
        libraryImages: [], 
        displayMedia: false,
        displayIfcMedia:false,
        displayIfcLogoMedia: false,
        displayIfcSignatureMedia: false,
        preimagepath: 'images/logo.png',
        preifcimagepath:'images/profile_pic.jpg',
        preifclogoimagepath:'images/footer_logo.png',
        preifcSignatureimagepath:'images/signature.png',
        preibcProfileimagepath:'images/profile_pic.jpg',
        preibcMainimagepath:'images/ibc_img.jpg',
        preibcLogoimagepath: 'images/ibc_logo.png',
        prebcLogoimagepath:'images/logo.png',
        textLogoFcValue: '',
        valueMedia:'',
        defaultValue:'',
        checkboxChoose:'',
        textInputValue: '',
        ifcCheckboxChoose: '',
        ifcLogoCheckboxChoose: '',
        ifcSignatureCheckboxChoose: '',
        ifcTextCheckboxChoose: '',
        ibcProfileImageCheckboxChoose: '',
        ifcRightTextCheckbox:'',
        ibcMainImageCheckboxChoose: '',
        ibcLogoImageCheckboxChoose: '',
        titleInputIfc:'Kat Nitsou',
        titleInputBC:'Kat Nitsou',
        previewContent : '',
       }
    },
    mounted(){
        this.getRightSide(1),
        $(document).ready(function(){
            $('[data-toggle="tooltip"]').tooltip(); 
        });
        this.ACTION_CHANGE_STATE(['defaultImagePath', this.preimagepath])
        this.ACTION_CHANGE_STATE(['defaultIfcImagePath', this.preifcimagepath])
        this.ACTION_CHANGE_STATE(['defaultIfcLogoPath', this.preifclogoimagepath])
        this.ACTION_CHANGE_STATE(['defaultIfcSignaturePath',this.preifcSignatureimagepath ])
        this.ACTION_CHANGE_STATE(['defaultIbcProfilePath', this.preibcProfileimagepath])
        this.ACTION_CHANGE_STATE(['defaultIbcMainImagePath', this.preibcMainimagepath])
        this.ACTION_CHANGE_STATE(['defaultIbcLogoImagePath', this.preibcLogoimagepath])
        this.ACTION_CHANGE_STATE(['defaultBcLogoImagePath', this.prebcLogoimagepath])
       var location = window.location
       //console.log(location.pathname)
       if(location.pathname == '/ifc'){
       // console.log(1)
        this.getRightSide(2),
        this.ACTION_CHANGE_STATE(["openModal", "inside-front-cover"])
       }else if(location.pathname == '/insideBackCover'){
        this.getRightSide(3)
       }else if(location.pathname == '/backCover') {
        this.getRightSide(4)
       }else{
           //console.log(2)
           this.ACTION_CHANGE_STATE(["openModal", "front-cover"])
       }
       
    }, 
    methods:{

        ...mapActions([
            'ACTION_CHANGE_STATE',
            'ACTION_ADD_VALUE_TO_FC_TEXT',
            'ACTION_ADD_VALUE_TO_IFC_LEFT_TEXT',
            'ACTION_ADD_VALUE_TO_IFC_RIGHT_TEXT'
            
        ]),
        ...mapMutations([
             'REMOVE_IMAGE_BACKROUND_PATH',
             'REMOVE_DEFAULT_IMAGE_PATH',
             'REMOVE_DEFAULT_IFC_IMAGE_PATH',
             'REMOVE_FC_TEXT_NULL',
             'USE_DEFAULT_MEDIA_IFC_IMAGE_PATH',
             'NUll_OPEN_IFC_MODAL_FOR_LOGO',
             'REMOVE_DEFAULT_IFC_LOGO_IMAGE_PATH',
             'USE_DEFAULT_MEDIA_IFC_LOGO_PATH',
             'REMOVE_MODEL_IFC_LOGO',
             'REMOVE_MODEL_IFC_TEXT',
             'NULL_CHECKBOX_BIND',
        ]),

        
        getRightSide(value){
            //console.log(value, 'sasasas')
            // $('.inner_left_side').addClass("active");
            
            if(value == 1){
                // this.ACTION_CHANGE_STATE(['showFrontCover', true])
                // this.ACTION_CHANGE_STATE(['showFrontInsideCover', false])
                this.ACTION_CHANGE_STATE(['showCover', 1])
            }
            else if(value == 2){
                // this.ACTION_CHANGE_STATE(['showFrontCover', false])
                // this.ACTION_CHANGE_STATE(['showFrontInsideCover', true])
                this.ACTION_CHANGE_STATE(['showCover', 2])
            }else if(value == 3){
                this.ACTION_CHANGE_STATE(['showCover', 3])
            }else if(value == 4){
                this.ACTION_CHANGE_STATE(['showCover', 4])
            }
        },
        displayModal (){
            if(this.openModal == 'front-cover'){
                console.log('sas')
                this.ACTION_CHANGE_STATE(['fcModalHide', 'true'])
                $('#exampleModal').modal('show');
            }
            console.log(this.openModal)
            if(this.openModal == 'inside-front-cover'){
                $('#ifcModal').modal('show');
            }
        },
        preiviewTab(){
            this.previewContent = $(".preview_content").html()
            this.ACTION_CHANGE_STATE(['previewFc', this.previewContent])
        },
        displayIfcModal(){
            $('#ifcModal').modal('show');
        },
        deleteLogo () {
            this.REMOVE_IMAGE_BACKROUND_PATH();
        },
        // getActive (event) {
        //     console.log(event , 'dgshd');
        // },
        setToImageShow (image) {
            //console.log(image, 'Rushi')
            if(this.setIfcLogo_bind == "addLogo") {
                this.ACTION_CHANGE_STATE(['imageIfcLogoPath', image]); 
            }else if(this.setIfc_bind == "addMedia"){
                this.ACTION_CHANGE_STATE(['imageIfcPath', image]);   
            }else if(this.setIfcSignature_bind == 'addSignature'){
                this.ACTION_CHANGE_STATE(['imageIfcSignaturePath', image]); 
            }else if(this.setIbcProfile_bind == 'profileImage'){
                this.ACTION_CHANGE_STATE(['imageIbcProfilePath', image])
            }else if (this.setIbcMainImage_bind == 'mainImage'){
                this.ACTION_CHANGE_STATE(['imageIbcMainPath', image])  
            }else if (this.setIbcLogoImage_bind == 'logoImage'){
                this.ACTION_CHANGE_STATE(['imageIbcLogoPath', image])  
            }else if (this.setBcLogoImage_bind == 'logoBCImage'){
                this.ACTION_CHANGE_STATE(['imageBcLogoPath', image])  
            }else{     
                this.ACTION_CHANGE_STATE(['imagePath', image]);
            }
        },
        getInputValue (value) {
        //    var test1= e.target.dataset.id
          //alert(value)
            this.checkboxChoose = value
            this.ACTION_CHANGE_STATE(['fcCheckboxChoose', this.checkboxChoose])
            if(this.checkboxChoose == "addMedia"){
                this.ACTION_CHANGE_STATE(['fcCheckboxChoose', 'addMedia'])
              // console.log($('.content_area').childNode)
               $(' div').prop('contenteditable', false)
                
                this.displayMedia = true;
                this.ACTION_CHANGE_STATE(['fcAddMediaShow', true])
                this.valueMedia = this.checkboxChoose
                this.REMOVE_FC_TEXT_NULL();
                $('.editable').html('');
                this.ACTION_CHANGE_STATE(['displayTextArea', false])    
            }else if (this.checkboxChoose == "default") {
                this.defaultValue = this.checkboxChoose
                this.REMOVE_FC_TEXT_NULL();
                this.displayMedia = false
                this.ACTION_CHANGE_STATE(['fcAddMediaShow', false])
                this.ACTION_CHANGE_STATE(['defaultImagePath', this.preimagepath])
                this.deleteLogo();
                this.REMOVE_FC_TEXT_NULL();
                $('.editable').html('');
                this.ACTION_CHANGE_STATE(['displayTextArea', false])
            }
            else if (this.checkboxChoose == "textLogo"){
                this.textLogoFcValue = this.checkboxChoose
                this.displayMedia = false
                this.ACTION_CHANGE_STATE(['fcAddMediaShow', false])
               this.ACTION_CHANGE_STATE(['displayTextArea', true])
               this.ACTION_CHANGE_STATE(['imagePath', '']);
            }
            else{
                this.displayMedia = false;
                this.REMOVE_DEFAULT_IMAGE_PATH()
                this.ACTION_CHANGE_STATE(['fcAddMediaShow', false])
                this.REMOVE_FC_TEXT_NULL();
                this.ACTION_CHANGE_STATE(['defaultImagePath', ''])
                this.ACTION_CHANGE_STATE(['displayTextArea', false])
            }
           
        },
        saveFCPreview(){
            this.fcContent = $('.preview_content').html(); 
            this.ACTION_CHANGE_STATE(['fcPreview', this.fcContent])
        },
        saveChanges () {
           
            this.saveFCPreview();
            var text = $('.editable').html();
            if(this.checkboxChoose == 'textLogo' || this.fcCheckboxChoose == 'textLogo'){
                alert('gone')
                this.ACTION_CHANGE_STATE(['fcLogoTextDisplay', true])
                this.ACTION_ADD_VALUE_TO_FC_TEXT(text)
                this.ACTION_CHANGE_STATE(['fcTextInputValueEditor', text])
                this.ACTION_CHANGE_STATE(['fcLogoText', text])
                this.ACTION_CHANGE_STATE(['hideFcText',false])
            }else{
                this.ACTION_CHANGE_STATE(['fcLogoText', ''])
                this.ACTION_CHANGE_STATE(['hideFcText',true])
                 this.ACTION_CHANGE_STATE(['fcLogoTextDisplay', false])
                 
            }
        },
        cancelModel () {
            // this.selectValue = ''
            this.displayMedia = false;
            this.NUll_OPEN_IFC_MODAL_FOR_LOGO()
            this.REMOVE_MODEL_IFC_TEXT()
            this.ACTION_CHANGE_STATE(['openIfcModalForSignature', ''])
        },
        addfont (command, showUI, value) {
            document.execCommand(command, showUI, value);
        },
        changeFontColor (color_picker) {
            this.addfont("foreColor", false, color_picker);
        },
        insertTag (headingTag) {
            document.execCommand('formatblock', false,  headingTag)
        },
        imgAlignStyle (style) {
            this.ACTION_CHANGE_STATE(["textAlign", style])
        },
        getvalue () {
           var text =  $('.editable').html()
           this.textInputValue = text
        },
        sendValue(value) {
            if(value == 1){
                this.ACTION_CHANGE_STATE(["openModal", "front-cover"])
            }
           if(value == 2){
            this.ACTION_CHANGE_STATE(["openModal", "inside-front-cover"])
           }
        },
        getIfcInputValue (value) {
            this.ifcCheckboxChoose = value
            if (this.ifcCheckboxChoose == "default") {
                this.displayIfcMedia = false
                this.ACTION_CHANGE_STATE(['defaultIfcImagePath', this.preifcimagepath])
            }
           var valueOfCheckbox = this.selectIfcValue
            if(this.ifcCheckboxChoose == "addMedia"){
                //console.log(valueOfCheckbox, 'scasa')
                 this.displayIfcMedia = true;
                 this.ACTION_CHANGE_STATE(["setIfc_bind","addMedia" ])
            }else{
                this.displayIfcMedia = false; 
        
            }
        },
        getIfcLogoInputValue (value) {
            this.ifcLogoCheckboxChoose = value
            if (this.ifcLogoCheckboxChoose == "default") {
                this.displayIfcLogoMedia = false
                this.ACTION_CHANGE_STATE(['defaultIfcLogoPath', this.preifclogoimagepath])
            }else if(this.ifcLogoCheckboxChoose == "addMedia"){
                 this.displayIfcLogoMedia = true;
                 this.ACTION_CHANGE_STATE(["setIfcLogo_bind","addLogo" ])
            }else{
                this.displayIfcLogoMedia = false;  
            }
        },
        getIfcSignatureInputValue(value){
            this.ifcSignatureCheckboxChoose = value
            if(this.ifcSignatureCheckboxChoose == 'default'){
                this.displayIfcSignatureMedia = false
                this.ACTION_CHANGE_STATE(['defaultIfcSignaturePath', this.preifcSignatureimagepath])
            }else if(this.ifcSignatureCheckboxChoose == 'addMedia') {
                this.displayIfcSignatureMedia = true;
                this.ACTION_CHANGE_STATE(["setIfcSignature_bind","addSignature" ])
            }else{
              
                this.displayIfcSignatureMedia = false
            }
        },
        getIfcTextInputValue (value) {
            this.ifcTextCheckboxChoose = value
           if (this.ifcTextCheckboxChoose == 'remove'){
               this.ACTION_CHANGE_STATE(['displayIfcTextArea', true])
           }
           else{
            this.ACTION_CHANGE_STATE(['displayIfcTextArea', false])
           }

        },
        getIbcInputValue(value){
          this.ibcProfileImageCheckboxChoose = value
          if(this.ibcProfileImageCheckboxChoose ==  'addMedia'){
              this.ACTION_CHANGE_STATE(['displayIbcProfileMedia', true])
              this.ACTION_CHANGE_STATE(['setIbcProfile_bind', 'profileImage'])
          }else if(this.ibcProfileImageCheckboxChoose == 'default'){
            this.ACTION_CHANGE_STATE(['defaultIbcProfilePath', this.preibcProfileimagepath])
            this.ACTION_CHANGE_STATE(['displayIbcProfileMedia', false])
          }else{
            this.ACTION_CHANGE_STATE(['displayIbcProfileMedia', false])
            this.ACTION_CHANGE_STATE(['defaultIbcProfilePath', ''])
          }
            //   this.ifcRightTextCheckbox = value
            //   if(this.ifcRightTextCheckbox == 'remove'){
            //     this.ACTION_CHANGE_STATE(['displayTextAreaFor', true])
            //   }else{
            //     this.ACTION_CHANGE_STATE(['displayTextAreaFor', false])
            //   }
        },
        getIbcMainImageInputValue(value) {
            this.ibcMainImageCheckboxChoose = value
            if(this.ibcMainImageCheckboxChoose ==  'addMedia'){
                this.ACTION_CHANGE_STATE(['displayIbcMainMedia', true])
                this.ACTION_CHANGE_STATE(['setIbcMainImage_bind', 'mainImage'])
            }else if(this.ibcMainImageCheckboxChoose == 'default'){
                this.ACTION_CHANGE_STATE(['defaultIbcMainImagePath', this.preibcMainimagepath])
                this.ACTION_CHANGE_STATE(['displayIbcMainMedia', false])
            }else{
                this.ACTION_CHANGE_STATE(['displayIbcMainMedia', false])
                this.ACTION_CHANGE_STATE(['defaultIbcMainImagePath', ''])
                this.ACTION_CHANGE_STATE(['imageIbcMainPath' , ''])
            } 
        },
        getIbcLogoImageInputValue(value){

            this.ibcLogoImageCheckboxChoose = value
            if(this.ibcLogoImageCheckboxChoose ==  'addMedia'){
                this.ACTION_CHANGE_STATE(['displayIbcLogoMedia', true])
                this.ACTION_CHANGE_STATE(['setIbcLogoImage_bind', 'logoImage'])
            }else if(this.ibcLogoImageCheckboxChoose == 'default'){
                this.ACTION_CHANGE_STATE(['defaultIbcLogoImagePath', this.preibcLogoimagepath])
                this.ACTION_CHANGE_STATE(['displayIbcLogoMedia', false])
            }else{
                this.ACTION_CHANGE_STATE(['displayIbcLogoMedia', false])
                this.ACTION_CHANGE_STATE(['defaultIbcLogoImagePath', ''])
                this.ACTION_CHANGE_STATE(['imageIbcLogoPath', ''])
            } 
        },
        getBcLogoImageInputValue(value){
            this.bcLogoImageCheckboxChoose = value
            if(this.bcLogoImageCheckboxChoose ==  'addMedia'){
                this.ACTION_CHANGE_STATE(['displayBcLogoMedia', true])
                this.ACTION_CHANGE_STATE(['setBcLogoImage_bind', 'logoBCImage'])
            }else if(this.bcLogoImageCheckboxChoose == 'default'){
                this.ACTION_CHANGE_STATE(['defaultBcLogoImagePath', this.prebcLogoimagepath])
                this.ACTION_CHANGE_STATE(['displayIbcLogoMedia', false])
            }else{
                this.ACTION_CHANGE_STATE(['displayBcLogoMedia', false])
                this.ACTION_CHANGE_STATE(['defaultBcLogoImagePath', ''])
                this.ACTION_CHANGE_STATE(['imageBcLogoPath', ''])
            } 
        },
        saveIFCPreview(){
            this.ifcContent = $('.preview_content').html(); 
            this.ACTION_CHANGE_STATE(['ifcPreview', this.ifcContent])
        },
        saveIfcChanges () {
            this.saveIFCPreview();
            this.NUll_OPEN_IFC_MODAL_FOR_LOGO()
            this.REMOVE_MODEL_IFC_TEXT()
            if( this.ifcTextCheckboxChoose == 'remove' ){

                var text = $('.editable').html();
                this.ACTION_CHANGE_STATE(['ifcTextDisplay', true])
                 this.ACTION_ADD_VALUE_TO_IFC_LEFT_TEXT(text)
                this.ACTION_CHANGE_STATE(['ifcText', text])

            }
            if( this.ifcTextCheckboxChoose == 'default' ){
                this.ACTION_CHANGE_STATE(['ifcTextDisplay', false])
            }
            if(this.ifcCheckboxChoose == 'remove' ){
                this.REMOVE_DEFAULT_IFC_IMAGE_PATH()
            }
            if(this.ifcCheckboxChoose == "default"){
                this.USE_DEFAULT_MEDIA_IFC_IMAGE_PATH()
            }
            if(this.ifcLogoCheckboxChoose == 'remove'){
                this.REMOVE_DEFAULT_IFC_LOGO_IMAGE_PATH()
            }
            if (this.ifcLogoCheckboxChoose == 'default'){
                this.USE_DEFAULT_MEDIA_IFC_LOGO_PATH()
            }
            if(this.ifcRightTextCheckbox == 'remove'){
                var text = $('.editable').html();
                this.ACTION_CHANGE_STATE(['ifcRightTextDisplay', true])
                //  this.ACTION_ADD_VALUE_TO_IFC_LEFT_TEXT(text)
                this.ACTION_CHANGE_STATE(['ifcRightText', text])
            }
            if(this.ifcRightTextCheckbox == "default" ) {
                this.ACTION_CHANGE_STATE(['ifcRightTextDisplay', false])
            }
            if(this.ifcSignatureCheckboxChoose == 'remove'){
                this.ACTION_CHANGE_STATE(['defaultIfcSignaturePath', ''])
            }
           // console.log(this.ifcSignatureCheckboxChoose )
            this.ifcTextCheckboxChoose = ''
            // this.NULL_CHECKBOX_BIND()
            this.ACTION_CHANGE_STATE(["setIfc_bind","" ])
            this.ACTION_CHANGE_STATE(["setIfcLogo_bind","" ])
            this.ACTION_CHANGE_STATE(["setIfcSignature_bind","" ])
            // this.displayIfcSignatureMedia = false
            this.ACTION_CHANGE_STATE(['openIfcModalForSignature', ''])
            this.ACTION_CHANGE_STATE(['openIfcModalForLogo', ''])
        },
        saveIBCPreview(){
            this.ibcContent = $('.preview_content').html(); 
            this.ACTION_CHANGE_STATE(['ibcPreview', this.ibcContent])
        },
        saveIbcChanges () {
            this.saveIBCPreview()
            //console.log(this.ibcProfileImageCheckboxChoose,'test123')
            if(this.ibcProfileImageCheckboxChoose == 'remove'){
                this.ACTION_CHANGE_STATE(['defaultIbcProfilePath', ''])
                this.ACTION_CHANGE_STATE(['imageIbcProfilePath', ''])
            }else if(this.ibcProfileImageCheckboxChoose == 'default'){
                this.ACTION_CHANGE_STATE(['imageIbcProfilePath', ''])
            }else if(this.ibcMainImageCheckboxChoose == 'remove'){
               this.ACTION_CHANGE_STATE(['imageIbcMainPath' , ''])
            }else if(this.ibcMainImageCheckboxChoose == 'default'){
                this.ACTION_CHANGE_STATE(['imageIbcMainPath' , ''])
            }else if(this.ibcLogoImageCheckboxChoose == 'remove'){
                this.ACTION_CHANGE_STATE(['imageIbcLogoPath', ''])  
            }else if(this.ibcLogoImageCheckboxChoose == 'default'){
                this.ACTION_CHANGE_STATE(['imageIbcLogoPath', ''])  
            } 
            this.ACTION_CHANGE_STATE(['setIbcProfile_bind', ''])
            this.ACTION_CHANGE_STATE(['setIbcMainImage_bind' , ''])
            this.ACTION_CHANGE_STATE(['setIbcLogoImage_bind' , ''])
            
        },
        saveBcChanges() {
            //this.saveIBCPreview()
            //console.log(this.bcLogoImageCheckboxChoose,'test123')
            if(this.bcLogoImageCheckboxChoose == 'remove'){
                this.ACTION_CHANGE_STATE(['defaultBcProfilePath', ''])
            }else if(this.bcLogoImageCheckboxChoose == 'default'){
                this.ACTION_CHANGE_STATE(['imageBcProfilePath', ''])
            } 
            this.ACTION_CHANGE_STATE(['setBcLogoImage_bind' , ''])
            
        },
        displayifclogo(e) { 
            alert('tests')
            var vget = e.path[3]
            var classModal = $(vget).attr('class')     
            //console.log(classModal,'Rushi')       
            var classPresentIbcLogo = $(vget).hasClass("ibc_logo")
            var classPresentIbcImage = $(vget).hasClass("inside_bc_img")
            var classPresentIbcProfileImage = $(vget).hasClass("ibc_profile")
            //console.log(classPresentIbcImage)
            var classPresentIbcProfile_text = $(vget).hasClass("profile_text")
            var classPresentbcProfile = $(vget).hasClass("ibc_logo")
            var classPresentbcText = $(vget).hasClass("bc_address")
            var classPresentbcHeader = $(vget).hasClass("bc_header")
            if(classModal == 'below_logo'){
                this.ACTION_CHANGE_STATE(['openIfcModalForLogo', 'ifc-logo'])
                this.REMOVE_MODEL_IFC_TEXT()
                this.ACTION_CHANGE_STATE(['openIfcModalForSignature', ''])
            }
            if(classModal ==  'profile_text'){
                this.ACTION_CHANGE_STATE(['openIfcModalForText', 'ifc-text'])
                //this.REMOVE_MODEL_IFC_LOGO()
                this.ACTION_CHANGE_STATE(['openIfcModalForLogo',''])
            }
            if(classModal ==  'col-sm-6 bc_address'){
                this.ACTION_CHANGE_STATE(['openIfcModalForText', 'ifc-text'])
                this.ACTION_CHANGE_STATE(['openFooterContent', 'footer-text'])
                this.ACTION_CHANGE_STATE(['openHeaderContent', ''])
                this.ACTION_CHANGE_STATE(['openIfcModalForLogo',''])
                //this.REMOVE_MODEL_IFC_LOGO()
            }
            if(classModal == 'right_ifc_content'){
                $('#ifcTextModal').modal('show')
            }
            if(classModal =='col-md-12 ibc_logo p-0'){
                $('#ifcTextModal1').modal('show'); 
            }
            if(classModal == 'bc_header'){
                this.ACTION_CHANGE_STATE(['openHeaderContent', 'header-text'])
                this.ACTION_CHANGE_STATE(['openFooterContent', ''])
                $('#bcAddressModal').modal('show');
            }
            if(classModal =='ifc_signature_image'){

                this.ACTION_CHANGE_STATE(['openIfcModalForSignature', 'ifc-signature'])
                $('#ifcModal').modal('show'); 
                /*REUSE THIS MODAL */
                // $('#ifcTextModal').modal('show')
                /*REUSE THIS MODAL */
            }else{
                $('#ifcModal').modal('show');     
            }
            

           /** For IBC images    **/
            if(classPresentIbcProfileImage == true){
                this.ACTION_CHANGE_STATE(['openIbcModal', 'profile'])
                $('#ifcTextModal').modal('show')
            }else if(classPresentIbcLogo == true) {
                this.ACTION_CHANGE_STATE(['openIbcModal', 'logoImage'])
                $('#ifcTextModal').modal('show'); 
            }else if(classPresentIbcImage == true){
                this.ACTION_CHANGE_STATE(['openIbcModal', 'mainImage'])
                $('#ifcTextModal').modal('show')
            }else if(classPresentbcProfile == true){
                $('#ibcAddressModal').modal('show')
            }else if(classPresentIbcProfile_text == true){
                $('#ibcAddressModal').modal('show')
            }else if(classPresentbcText == true){
                $('#bcAddressModal').modal('show')
            }
        },
        
        check_Value (value) {
            //console.log(value, 'value')
            if(value == 1){
                if(this.ifcCheckboxChoose == 'addMedia'){
                    this.ACTION_CHANGE_STATE(["setIfc_bind","addMedia" ])
                }
            }else if (value == 2){
                if(this.ifcLogoCheckboxChoose == 'addMedia'){
                 this.ACTION_CHANGE_STATE(["setIfcLogo_bind","addLogo" ])
                }     
            }else if(value == 3){
                if(this.ifcSignatureCheckboxChoose == 'addMedia'){
                    this.ACTION_CHANGE_STATE(['setIfcSignature_bind', 'addSignature'])
                } 
            }else if(value == 'ibcProfile') {
                if(this.ibcProfileImageCheckboxChoose ==  'addMedia'){
                    this.ACTION_CHANGE_STATE(['setIbcProfile_bind', 'profileImage'])
                }
            }else if(value == 'ibcMainImage'){
                if(this.ibcMainImageCheckboxChoose ==  'addMedia'){
                    this.ACTION_CHANGE_STATE(['setIbcMainImage_bind', 'mainImage'])
                }
            }else if(value == 'ibcLogoImage'){
                if(this.ibcLogoImageCheckboxChoose ==  'addMedia'){
                    this.ACTION_CHANGE_STATE(['setIbcLogoImage_bind', 'logoImage'])
                }
            }else if(value == 'BcLogoImage'){
                if(this.bcLogoImageCheckboxChoose ==  'addMedia'){
                    this.ACTION_CHANGE_STATE(['setBcLogoImage_bind', 'logoBCImage'])
                }
            }    
        },
        getTitleIfc (value) {
           //console.log(value)
           this.ACTION_CHANGE_STATE(['ifcTitleText', value])
        }, 
        getCompanyNameIfc (value){
            this.ACTION_CHANGE_STATE(['ifcCompanyName', value])
        },
        getdesignationIfc1 (value) {
            this.ACTION_CHANGE_STATE(['designation1', value])
        },
        getdesignationIfc2 (value) {
            this.ACTION_CHANGE_STATE(['designation2', value])
        },
        getdesignationIfc3 (value) {
            this.ACTION_CHANGE_STATE(['designation3', value])
        },
        getdesignationTitleIfc1 (value) {
            this.ACTION_CHANGE_STATE(['designationTitle1', value])
        },
        getdesignationTitleIfc2 (value) {
            this.ACTION_CHANGE_STATE(['designationTitle2', value])
        },
        getdesignationTitleIfc3 (value) {
            this.ACTION_CHANGE_STATE(['designationTitle3', value])
        },
        getdesignationTitleIfc4(value) {
            this.ACTION_CHANGE_STATE(['designationTitle4', value])
        },
        getAddressIfc1 (value){
            this.ACTION_CHANGE_STATE(['addressIfc1', value])
        },
        getdirectPhoneIfc (value) {
            this.ACTION_CHANGE_STATE(['directPhoneIfc', value])
        },
        getOfficePhoneIfc (value) {
            this.ACTION_CHANGE_STATE(['officePhone', value])
        },
        getWebsiteUrlIfc (value) {
            this.ACTION_CHANGE_STATE(['websiteUrlIfc', value])
        },
        getEmailIfc( value) {
            this.ACTION_CHANGE_STATE(['emailIfc', value])
        },
        getstNumberIfc (value) {
            this.ACTION_CHANGE_STATE(['stNumberIfc', value])
        },
        editIfcRight() {
            this.ACTION_CHANGE_STATE(['showTextAreaIfcRight', true])   
        },
        getTitleIbc (value){this.ACTION_CHANGE_STATE(['ibcTitleText', value])},
        getCompanyNameIbc(value){this.ACTION_CHANGE_STATE(['ibcCompanyNameText', value])},
        getAddressIbc(value){this.ACTION_CHANGE_STATE(['ibcAddressText', value])},
        getAddressIbc1(value){this.ACTION_CHANGE_STATE(['ibcAddressText1', value])},
        getdirectPhoneIbc(value){this.ACTION_CHANGE_STATE(['ibcPhoneNumberText', value])},
        getOfficePhoneIbc(value){this.ACTION_CHANGE_STATE(['ibcOfficeNumberText', value])},
        getWebsiteUrlIbc(value){this.ACTION_CHANGE_STATE(['ibcWebsiteText', value])},
        getEmailIbc(value){this.ACTION_CHANGE_STATE(['ibcEmailText', value])},
        saveIfcRight (){
            this.saveIFCPreview()
            this.ACTION_CHANGE_STATE(['showTextAreaIfcRight', false])
            //console.log($('.editable_ifc_text').html())
            var text = $('.editable_ifc_text').html() 
            this.ACTION_ADD_VALUE_TO_IFC_RIGHT_TEXT(text)
            this.ACTION_CHANGE_STATE(['ifcRightTextInputValue', text])
        },
        getTitleBc (value){ this.ACTION_CHANGE_STATE(['bcTitleText', value])},
        getCompanyNameBc(value){this.ACTION_CHANGE_STATE(['bcCompanyNameText', value])},
        getAddressBc(value){this.ACTION_CHANGE_STATE(['bcAddressText', value])},
        getAddressBc1(value){this.ACTION_CHANGE_STATE(['bcAddressText1', value])},
        getdirectPhoneBc(value){this.ACTION_CHANGE_STATE(['bcPhoneNumberText', value])},
        getOfficePhoneBc1(value){this.ACTION_CHANGE_STATE(['bcOfficeNumberText', value])},
        getWebsiteUrlBc(value){this.ACTION_CHANGE_STATE(['bcWebsiteText', value])},
        getEmailBc(value){this.ACTION_CHANGE_STATE(['bcEmailText', value])},
        
        getTitleHeaderBc (value){ this.ACTION_CHANGE_STATE(['bcTitleHeaderText', value])},
        getAddressHeaderBc(value){this.ACTION_CHANGE_STATE(['bcAddressHeaderBcText', value])},
        getAddressHeaderBc1(value){this.ACTION_CHANGE_STATE(['bcAddressHeaderBc1Text', value])},
        getCityHeaderBc(value){this.ACTION_CHANGE_STATE(['bcCityHeaderText', value])},
        getCountryHeaderBc(value){this.ACTION_CHANGE_STATE(['bcCountryHeaderText', value])},
        changeView(viewData){
            if(viewData == 'desktop'){
                $('.preview_responsive').css('width','100%')
                $('.preview_responsive').addClass('desktop')
                $('.preview_responsive').removeClass('tablet')
                $('.preview_responsive').removeClass('mobile')

            }else if(viewData == 'tablet'){
                $('.preview_responsive').css('width','768px')
                $('.preview_responsive').addClass('tablet')
                $('.preview_responsive').removeClass('desktop')
                $('.preview_responsive').removeClass('mobile')
            }else{
                $('.preview_responsive').css('width','480px')
                $('.preview_responsive').addClass('mobile')
                $('.preview_responsive').removeClass('desktop')
                $('.preview_responsive').removeClass('tablet')
            }
        }, 
        fetchHtml(value){
            //alert(value)
            //var text =$('.preview_content').html();
            var fcPreviewHtml= this.$store.state.fcPreview  
            var ifcPreviewHtml= this.$store.state.ifcPreview 
            var ibcPreviewHtml= this.$store.state.ibcPreview
            var allHtml =  fcPreviewHtml+ifcPreviewHtml+ibcPreviewHtml
          //   console.log(allHtml, ';sas')
          this.style_html(allHtml)
           
          },

        /*For html Format into multiple line */   
        getIndent(level) {
            var result = '',
                i = level * 4;
            if (level < 0) {
                throw "Level is below 0";
            }
            while (i--) {
                result += ' ';
            }
            return result;
        },
        style_html(html) {
           // console.log(html, 'sahsh')
           
            html = html.trim();
            var result = '',
                indentLevel = 0,
                tokens = html.split(/</);
            for (var i = 0, l = tokens.length; i < l; i++) {
                var parts = tokens[i].split(/>/);
                if (parts.length === 2) {
                    if (tokens[i][0] === '/') {
                        indentLevel--;
                    }
                    result += this.getIndent(indentLevel);
                    if (tokens[i][0] !== '/') {
                        indentLevel++;
                    }
    
                    if (i > 0) {
                        result += '<';
                    }
    
                    result += parts[0].trim() + ">\n";
                    if (parts[1].trim() !== '') {
                        result += this.getIndent(indentLevel) + parts[1].trim().replace(/\s+/g, ' ') + "\n";
                    }
    
                    if (parts[0].match(/^(img|hr|br)/)) {
                        indentLevel--;
                    }
                } else {
                    result += this.getIndent(indentLevel) + parts[0] + "\n";
                }
            }
            console.log(result)
            return result;
        },
        saveFcValueToDb(){
           
            console.log(this.checkboxChoose, 'sasgahg')
           var data ={
              columnName:'front_cover',
              defaultImage:this.defaultImagePath,
              AddedImage:this.imagePath,
              textLogo:this.fcLogoText,
              checkboxChoose:this.fcCheckboxChoose
              
            }
            console.log(data, 'data')
           
            axios.post("api/userBooks", data)
            .then(response => {
                console.log(response, "success");
            })
            .catch(errorResponse => {
                console.log(errorResponse, "errorResponse");
            });
        }, 
        async getfcUserBook(){
            await axios.get("api/userBooks/1")
            .then(response => {
                console.log(response.data.data.front_cover.checkboxChoose);
                var checkboxSelected = response.data.data.front_cover.checkboxChoose
                if(response.data.data.front_cover.checkboxChoose =='default'){
                    console.log(response.data.data.front_cover.defaultImage, "success");
                    this.ACTION_CHANGE_STATE(['fcCheckboxChoose',checkboxSelected ])
                }else if(response.data.data.front_cover.checkboxChoose =='addMedia'){
                    console.log(response.data.data.front_cover.AddedImage, "success");
                    alert('here')
                    this.ACTION_CHANGE_STATE(['fcAddMediaShow', true])
                    var updatedImagePath = response.data.data.front_cover.AddedImage
                    this.ACTION_CHANGE_STATE(['imagePath', updatedImagePath]);
                    this.ACTION_CHANGE_STATE(['fcCheckboxChoose',checkboxSelected ])
                }else if(response.data.data.front_cover.checkboxChoose =='textLogo'){
                    console.log(response.data.data.front_cover.textLogo, "success");
                    var dbfctextlogo = response.data.data.front_cover.textLogo 
                    this.ACTION_CHANGE_STATE(['fcLogoText', dbfctextlogo])
                    this.ACTION_CHANGE_STATE(['fcTextInputValueEditor', dbfctextlogo])
                    this.ACTION_CHANGE_STATE(['defaultImagePath', ''])
                    this.ACTION_CHANGE_STATE(['fcLogoTextDisplay', true])
                    this.ACTION_CHANGE_STATE(['hideFcText',false])
                    this.ACTION_CHANGE_STATE(['fcCheckboxChoose',checkboxSelected ])
                    this.ACTION_CHANGE_STATE(['displayTextArea', true])
                }else{
                    this.ACTION_CHANGE_STATE(['fcCheckboxChoose',checkboxSelected ])
                    this.ACTION_CHANGE_STATE(['defaultImagePath', ''])
                }
            })
            .catch(errorResponse => {
                console.log(errorResponse, "errorResponse");
            });
        } 
    }
    
}